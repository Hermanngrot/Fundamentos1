#pragma once
using namespace System;

public ref class User {
public:
	int id;
	String^ name;
	String^ email;
	String^ phone;
	String^ address;
	String^ password;
};