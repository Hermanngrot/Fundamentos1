#include "MyForm.h"
#include "mainform.h"
#include "registro.h"

using namespace System;
using namespace System::Windows::Forms;

[STAThread] // Asegura que el modelo de subprocesos sea STA, necesario para Windows Forms
int main(array<String^>^ args) { // Usa correctamente el tipo gestionado de .NET
    Application::EnableVisualStyles();
    Application::SetCompatibleTextRenderingDefault(false);
    User^ user = nullptr;

    // Ciclo para manejar login y registro
    while (true) {
        loginfinal::MyForm myform;
        myform.ShowDialog();

        if (myform.switchToRegister) {
            loginfinal::registro registroform;
            registroform.ShowDialog();

            if (registroform.switchToLogin) {
                continue; // Volver al login
            }
            else {
                user = registroform.user; // Usuario registrado
                break;
            }
        }
        else {
            user = myform.user; // Usuario autenticado
            break;
        }
    }

    // Abrir la ventana principal si se autentic� o registr� un usuario
    if (user != nullptr) {
        loginfinal::mainform mainform(user);
        Application::Run(% mainform);
    }
    else {
        MessageBox::Show("Authentication Canceled",
            "Program.cpp", MessageBoxButtons::OK);
    }

    return 0;
}






