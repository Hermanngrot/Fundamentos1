#pragma once

namespace loginfinal {

    using namespace System;
    using namespace System::ComponentModel;
    using namespace System::Collections;
    using namespace System::Windows::Forms;
    using namespace System::Data;
    using namespace System::Drawing;
    using namespace System::Data::SqlClient;
    using namespace System::IO;  // Necesario para el manejo de archivos

    public ref class agregardispositivo : public System::Windows::Forms::Form
    {
    public:
        agregardispositivo(void)
        {
            InitializeComponent();
        }

    protected:
        ~agregardispositivo()
        {
            if (components)
            {
                delete components;
            }
        }

    private:
        System::Windows::Forms::Label^ label1;
        System::Windows::Forms::Label^ label2;
        System::Windows::Forms::TextBox^ textBox1;
        System::Windows::Forms::TextBox^ textBox2;
        System::Windows::Forms::Label^ label3;
        System::Windows::Forms::Label^ label4;
        System::Windows::Forms::TextBox^ textBox3;
        System::Windows::Forms::Button^ btnGuardar;
        System::Windows::Forms::Label^ label5;

    protected:

    private:
        System::ComponentModel::Container^ components;

#pragma region Windows Form Designer generated code
        void InitializeComponent(void)
        {
            this->label1 = (gcnew System::Windows::Forms::Label());
            this->label2 = (gcnew System::Windows::Forms::Label());
            this->textBox1 = (gcnew System::Windows::Forms::TextBox());
            this->textBox2 = (gcnew System::Windows::Forms::TextBox());
            this->label3 = (gcnew System::Windows::Forms::Label());
            this->label4 = (gcnew System::Windows::Forms::Label());
            this->textBox3 = (gcnew System::Windows::Forms::TextBox());
            this->btnGuardar = (gcnew System::Windows::Forms::Button());
            this->label5 = (gcnew System::Windows::Forms::Label());
            this->SuspendLayout();
            // 
            // label1
            // 
            this->label1->AutoSize = true;
            this->label1->BackColor = System::Drawing::Color::SteelBlue;
            this->label1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 24));
            this->label1->Location = System::Drawing::Point(747, 63);
            this->label1->Name = L"label1";
            this->label1->Size = System::Drawing::Size(441, 46);
            this->label1->TabIndex = 0;
            this->label1->Text = L"Agrega tus dispositivos ";
            // 
            // label2
            // 
            this->label2->AutoSize = true;
            this->label2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 18));
            this->label2->Location = System::Drawing::Point(332, 187);
            this->label2->Name = L"label2";
            this->label2->Size = System::Drawing::Size(459, 36);
            this->label2->TabIndex = 1;
            this->label2->Text = L"Ingresa el id del dispositivo:";
            // 
            // textBox1
            // 
            this->textBox1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 16.2F));
            this->textBox1->Location = System::Drawing::Point(1098, 185);
            this->textBox1->Name = L"textBox1";
            this->textBox1->Size = System::Drawing::Size(356, 38);
            this->textBox1->TabIndex = 2;
            // 
            // textBox2
            // 
            this->textBox2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 18));
            this->textBox2->Location = System::Drawing::Point(1098, 560);
            this->textBox2->Name = L"textBox2";
            this->textBox2->Size = System::Drawing::Size(356, 41);
            this->textBox2->TabIndex = 3;
            // 
            // label3
            // 
            this->label3->Location = System::Drawing::Point(0, 0);
            this->label3->Name = L"label3";
            this->label3->Size = System::Drawing::Size(100, 23);
            this->label3->TabIndex = 8;
            // 
            // label4
            // 
            this->label4->AutoSize = true;
            this->label4->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 16.2F));
            this->label4->Location = System::Drawing::Point(73, 360);
            this->label4->Name = L"label4";
            this->label4->Size = System::Drawing::Size(811, 32);
            this->label4->TabIndex = 5;
            this->label4->Text = L"Ingrese la cantidad de hectarias que puede regar el dispositivo:";
            // 
            // textBox3
            // 
            this->textBox3->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 16.2F));
            this->textBox3->Location = System::Drawing::Point(1098, 360);
            this->textBox3->Name = L"textBox3";
            this->textBox3->Size = System::Drawing::Size(356, 38);
            this->textBox3->TabIndex = 6;
            // 
            // btnGuardar
            // 
            this->btnGuardar->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 16));
            this->btnGuardar->Location = System::Drawing::Point(900, 700);
            this->btnGuardar->Name = L"btnGuardar";
            this->btnGuardar->Size = System::Drawing::Size(200, 50);
            this->btnGuardar->TabIndex = 7;
            this->btnGuardar->Text = L"Guardar";
            this->btnGuardar->UseVisualStyleBackColor = true;
            this->btnGuardar->Click += gcnew System::EventHandler(this, &agregardispositivo::btnGuardar_Click);
            // 
            // label5
            // 
            this->label5->AutoSize = true;
            this->label5->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 16.2F));
            this->label5->Location = System::Drawing::Point(73, 569);
            this->label5->Name = L"label5";
            this->label5->Size = System::Drawing::Size(474, 32);
            this->label5->TabIndex = 9;
            this->label5->Text = L"Ingrese la hora del riego automatico:";
            // 
            // agregardispositivo
            // 
            this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
            this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
            this->BackColor = System::Drawing::Color::CadetBlue;
            this->ClientSize = System::Drawing::Size(1825, 895);
            this->Controls->Add(this->label5);
            this->Controls->Add(this->btnGuardar);
            this->Controls->Add(this->textBox3);
            this->Controls->Add(this->label4);
            this->Controls->Add(this->label3);
            this->Controls->Add(this->textBox2);
            this->Controls->Add(this->textBox1);
            this->Controls->Add(this->label2);
            this->Controls->Add(this->label1);
            this->Name = L"agregardispositivo";
            this->Text = L"agregardispositivo";
            this->Load += gcnew System::EventHandler(this, &agregardispositivo::agregardispositivo_Load);
            this->ResumeLayout(false);
            this->PerformLayout();

        }
#pragma endregion

    private:
        System::Void btnGuardar_Click(System::Object^ sender, System::EventArgs^ e)
        {
            String^ nombreDispositivo = textBox1->Text;
            String^ cantidadHectareas = textBox3->Text;
            String^ horaRiego = textBox2->Text;

            if (String::IsNullOrWhiteSpace(nombreDispositivo) || String::IsNullOrWhiteSpace(cantidadHectareas) || String::IsNullOrWhiteSpace(horaRiego))
            {
                MessageBox::Show("Por favor, completa todos los campos.", "Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
                return;
            }

            try
            {
                // Guardar SOLO en archivo de texto
                String^ rutaArchivo = "preferencias.txt";
                StreamWriter^ sw = gcnew StreamWriter(rutaArchivo, true); // El true indica que se agregar�n los datos al final del archivo
                sw->WriteLine("Id del Dispositivo: " + nombreDispositivo);
                sw->WriteLine("Hectareas: " + cantidadHectareas);
                sw->WriteLine("Hora de Riego: " + horaRiego);
                sw->WriteLine("--------------------------------------------------");
                sw->Close();

                MessageBox::Show("Dispositivo guardado exitosamente en el archivo de texto.", "�xito", MessageBoxButtons::OK, MessageBoxIcon::Information);
            }
            catch (Exception^ ex)
            {
                MessageBox::Show("Error al guardar el dispositivo: " + ex->Message, "Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
            }
        }
    private: System::Void agregardispositivo_Load(System::Object^ sender, System::EventArgs^ e) {
    }
};
}