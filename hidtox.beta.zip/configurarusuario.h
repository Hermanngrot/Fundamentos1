#pragma once 

namespace loginfinal {

    using namespace System;
    using namespace System::ComponentModel;
    using namespace System::Collections;
    using namespace System::Windows::Forms;
    using namespace System::Data;
    using namespace System::Drawing;
    using namespace System::Data::SqlClient; // Para manejar la conexi�n a la base de datos SQL

    public ref class configurarusuario : public System::Windows::Forms::Form
    {
    public:
        configurarusuario(void)
        {
            InitializeComponent();
            CargarOpciones();  // Llamar a la funci�n que carga las opciones al ComboBox
        }

    protected:
        ~configurarusuario()
        {
            if (components)
            {
                delete components;
            }
        }

    private: System::Windows::Forms::Label^ label1;
    protected:

    private: System::Windows::Forms::Label^ label2;
    private: System::Windows::Forms::Label^ label3;
    private: System::Windows::Forms::Label^ label4;
    private: System::Windows::Forms::ComboBox^ comboBox1;
    private: System::Windows::Forms::TextBox^ textBox2;
    private: System::Windows::Forms::Button^ button1;

    private:
        System::ComponentModel::Container^ components;

#pragma region Windows Form Designer generated code
        void InitializeComponent(void)
        {
            this->label1 = (gcnew System::Windows::Forms::Label());
            this->label2 = (gcnew System::Windows::Forms::Label());
            this->label3 = (gcnew System::Windows::Forms::Label());
            this->label4 = (gcnew System::Windows::Forms::Label());
            this->comboBox1 = (gcnew System::Windows::Forms::ComboBox());
            this->textBox2 = (gcnew System::Windows::Forms::TextBox());
            this->button1 = (gcnew System::Windows::Forms::Button());
            this->SuspendLayout();
            // 
            // button1
            // 
            this->button1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 16.2F));
            this->button1->Location = System::Drawing::Point(857, 676);
            this->button1->Name = L"button1";
            this->button1->Size = System::Drawing::Size(165, 48);
            this->button1->TabIndex = 7;
            this->button1->Text = L"Guardar";
            this->button1->UseVisualStyleBackColor = true;
            this->button1->Click += gcnew System::EventHandler(this, &configurarusuario::button1_Click);
            // 
            // configurarusuario
            // 
            this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
            this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
            this->BackColor = System::Drawing::Color::PaleTurquoise;
            this->ClientSize = System::Drawing::Size(1434, 784);
            this->Controls->Add(this->button1);
            this->Controls->Add(this->textBox2);
            this->Controls->Add(this->comboBox1);
            this->Controls->Add(this->label4);
            this->Controls->Add(this->label3);
            this->Controls->Add(this->label2);
            this->Controls->Add(this->label1);
            this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::FixedDialog;
            this->Name = L"configurarusuario";
            this->Text = L"configurarusuario";
            this->ResumeLayout(false);
            this->PerformLayout();
        }
#pragma endregion

        // M�todo para cargar las opciones al ComboBox
    private: System::Void CargarOpciones()
    {
        // Llenar el ComboBox con las opciones de campos que se pueden modificar
        comboBox1->Items->Add("name");
        comboBox1->Items->Add("phone");
        comboBox1->Items->Add("address");
        comboBox1->Items->Add("password");
        comboBox1->Items->Add("email");
    }

           // Evento del bot�n Guardar
    private: System::Void button1_Click(System::Object^ sender, System::EventArgs^ e)
    {
        // Verificar si se ha seleccionado una opci�n y si el TextBox no est� vac�o
        if (comboBox1->SelectedItem != nullptr && !String::IsNullOrEmpty(textBox2->Text))
        {
            // Obtener el valor seleccionado del ComboBox y el texto del TextBox
            String^ campoAActualizar = comboBox1->SelectedItem->ToString();  // Lo que se va a modificar
            String^ nuevoValor = textBox2->Text;  // Nuevo valor a registrar

            // Obtener el ID del usuario logueado
            int id_usuario = ObtenerIdUsuarioLogueado();  // Aqu� obtienes el ID del usuario actual

            // Cadena de conexi�n a la base de datos
            String^ connectionString = "Data Source=LAPTOP-FGOVNBET;Initial Catalog=master;Integrated Security=True;Encrypt=False;"; // Ajustar seg�n tu configuraci�n

            // Crear la consulta SQL para actualizar el campo en la base de datos
            String^ query = "UPDATE users SET " + campoAActualizar + " = @nuevoValor WHERE id = @id_usuario"; // Cambiado 'Usuarios' a 'users'

            // Crear la conexi�n y el comando SQL
            SqlConnection^ connection = gcnew SqlConnection(connectionString);
            SqlCommand^ command = gcnew SqlCommand(query, connection);

            // Aseg�rate de agregar los par�metros a la consulta para prevenir inyecciones SQL
            command->Parameters->AddWithValue("@nuevoValor", nuevoValor);
            command->Parameters->AddWithValue("@id_usuario", id_usuario);  // Aqu� usamos el ID din�mico

            try
            {
                // Abrir la conexi�n
                connection->Open();
                // Ejecutar el comando
                command->ExecuteNonQuery();
                // Confirmar que se ha realizado la modificaci�n
                MessageBox::Show("Datos actualizados correctamente.");
            }
            catch (Exception^ ex)
            {
                // Si ocurre alg�n error, mostrarlo
                MessageBox::Show("Error al actualizar los datos: " + ex->Message);
            }
            finally
            {
                // Cerrar la conexi�n
                connection->Close();
            }
        }
        else
        {
            MessageBox::Show("Por favor, selecciona una opci�n y proporciona un nuevo valor.");
        }
    }

           // Simulaci�n de la funci�n que obtiene el ID del usuario logueado
    private: int ObtenerIdUsuarioLogueado()
    {
        // Aqu� deber�as implementar la l�gica para obtener el ID del usuario logueado
        // Esto puede variar seg�n c�mo gestionas el inicio de sesi�n en tu aplicaci�n
        return 1;  // Por ahora, retorna un valor de ejemplo (ID del usuario logueado)
    }
    };

}


