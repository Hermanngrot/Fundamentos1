#pragma once

namespace loginfinal {

    using namespace System;
    using namespace System::ComponentModel;
    using namespace System::Collections;
    using namespace System::Windows::Forms;
    using namespace System::Data;
    using namespace System::Drawing;
    using namespace System::IO;  // Necesario para el manejo de archivos

    public ref class mostrarregadores : public System::Windows::Forms::Form
    {
    public:
        mostrarregadores(void)
        {
            InitializeComponent();
        }

    protected:
        ~mostrarregadores()
        {
            if (components)
            {
                delete components;
            }
        }

    private:
        System::Windows::Forms::Label^ label1;
        System::Windows::Forms::FlowLayoutPanel^ flowLayoutPanel1; // Contenedor para los dispositivos
        System::ComponentModel::Container^ components;

#pragma region Windows Form Designer generated code
        void InitializeComponent(void)
        {
            this->label1 = (gcnew System::Windows::Forms::Label());
            this->flowLayoutPanel1 = (gcnew System::Windows::Forms::FlowLayoutPanel());
            this->SuspendLayout();
            // 
            // label1
            // 
            this->label1->AutoSize = true;
            this->label1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 19.8F));
            this->label1->Location = System::Drawing::Point(658, 28);
            this->label1->Name = L"label1";
            this->label1->Size = System::Drawing::Size(177, 38);
            this->label1->TabIndex = 0;
            this->label1->Text = L"Regadores";
            // 
            // flowLayoutPanel1
            // 
            this->flowLayoutPanel1->AutoScroll = true;
            this->flowLayoutPanel1->Location = System::Drawing::Point(221, 100);
            this->flowLayoutPanel1->Name = L"flowLayoutPanel1";
            this->flowLayoutPanel1->Size = System::Drawing::Size(800, 500);
            this->flowLayoutPanel1->TabIndex = 1;
            // 
            // mostrarregadores
            // 
            this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
            this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
            this->BackColor = System::Drawing::Color::Turquoise;
            this->ClientSize = System::Drawing::Size(1351, 771);
            this->Controls->Add(this->flowLayoutPanel1);
            this->Controls->Add(this->label1);
            this->Name = L"mostrarregadores";
            this->Text = L"Mostrar Regadores";
            this->Load += gcnew System::EventHandler(this, &mostrarregadores::mostrarregadores_Load);
            this->ResumeLayout(false);
            this->PerformLayout();
        }
#pragma endregion

    private: System::Void mostrarregadores_Load(System::Object^ sender, System::EventArgs^ e)
    {
        // Cargar los dispositivos desde el archivo
        try
        {
            String^ rutaArchivo = "preferencias.txt";
            if (File::Exists(rutaArchivo))
            {
                array<String^>^ lines = File::ReadAllLines(rutaArchivo);
                for each(String ^ line in lines)
                {
                    if (line->StartsWith("Id del Dispositivo: "))
                    {
                        // Crear un Label para el ID
                        Label^ labelId = gcnew Label();
                        labelId->Text = line; // Establecer el ID del dispositivo
                        labelId->Font = gcnew System::Drawing::Font(L"Microsoft Sans Serif", 14);
                        labelId->AutoSize = true;
                        labelId->Margin = System::Windows::Forms::Padding(10); // Establecer el margen correctamente

                        // Crear un bot�n para encender/apagar
                        Button^ btnTogglePower = gcnew Button();
                        btnTogglePower->Text = "Encender";
                        btnTogglePower->Size = System::Drawing::Size(120, 40);
                        btnTogglePower->Click += gcnew System::EventHandler(this, &mostrarregadores::btnTogglePower_Click);

                        // A�adir el Label y el bot�n al FlowLayoutPanel
                        flowLayoutPanel1->Controls->Add(labelId);
                        flowLayoutPanel1->Controls->Add(btnTogglePower);
                    }
                }
            }
            else
            {
                MessageBox::Show("No se encontr� el archivo de preferencias.", "Error", MessageBoxButtons::OK, MessageBoxIcon::Warning);
            }
        }
        catch (Exception^ ex)
        {
            MessageBox::Show("Error al leer el archivo: " + ex->Message, "Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
        }
    }

    private: System::Void btnTogglePower_Click(System::Object^ sender, System::EventArgs^ e)
    {
        // Cambiar el texto del bot�n de Encender a Apagar y viceversa
        Button^ btn = dynamic_cast<Button^>(sender);
        if (btn)
        {
            if (btn->Text == "Encender")
            {
                btn->Text = "Apagar";
                MessageBox::Show("Dispositivo encendido.");
            }
            else
            {
                btn->Text = "Encender";
                MessageBox::Show("Dispositivo apagado.");
            }
        }
    }
    };
}





