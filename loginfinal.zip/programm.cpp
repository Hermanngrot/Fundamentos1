
#include "MyForm.h"
using namespace System;
using namespace System::Windows::Forms;

int main(array<String^>^ args) {
	Application::EnableVisualStyles();
	Application::SetCompatibleTextRenderingDefault(false);
	loginfinal::MyForm MyForm;
	MyForm.ShowDialog();
	User^ user = MyForm.user;
	if (user != nullptr) {
		MessageBox::Show("Successfull Authetication of " + user->name,
			"programm.cpp", MessageBoxButtons::OK);
	}
	else {
		MessageBox::Show("Authetication Canceled",
			"Programm.cpp", MessageBoxButtons::OK);
	}
}


