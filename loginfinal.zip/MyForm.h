#pragma once
#include"User.h"
namespace loginfinal {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace System::Data::SqlClient;
	/// <summary>
	/// Resumen de MyForm
	/// </summary>
	public ref class MyForm : public System::Windows::Forms::Form
	{
	public:
		MyForm(void)
		{
			InitializeComponent();
			//
			//TODO: agregar c�digo de constructor aqu�
			//
		}

	protected:
		/// <summary>
		/// Limpiar los recursos que se est�n usando.
		/// </summary>
		~MyForm()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^ email;
	private: System::Windows::Forms::TextBox^ emailtext;
	private: System::Windows::Forms::TextBox^ passwordtext;

	private: System::Windows::Forms::Label^ password;
	private: System::Windows::Forms::Button^ okbutton;
	private: System::Windows::Forms::Button^ cancelbutton;
	private: System::Windows::Forms::Label^ login;

	protected:

	protected:

	private:
		/// <summary>
		/// Variable del dise�ador necesaria.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// M�todo necesario para admitir el Dise�ador. No se puede modificar
		/// el contenido de este m�todo con el editor de c�digo.
		/// </summary>
		void InitializeComponent(void)
		{
			this->email = (gcnew System::Windows::Forms::Label());
			this->emailtext = (gcnew System::Windows::Forms::TextBox());
			this->passwordtext = (gcnew System::Windows::Forms::TextBox());
			this->password = (gcnew System::Windows::Forms::Label());
			this->okbutton = (gcnew System::Windows::Forms::Button());
			this->cancelbutton = (gcnew System::Windows::Forms::Button());
			this->login = (gcnew System::Windows::Forms::Label());
			this->SuspendLayout();
			// 
			// email
			// 
			this->email->AutoSize = true;
			this->email->BackColor = System::Drawing::SystemColors::Control;
			this->email->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 13.8F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->email->Location = System::Drawing::Point(44, 93);
			this->email->Name = L"email";
			this->email->Size = System::Drawing::Size(93, 29);
			this->email->TabIndex = 0;
			this->email->Text = L"Email: ";
			this->email->Click += gcnew System::EventHandler(this, &MyForm::label1_Click);
			// 
			// emailtext
			// 
			this->emailtext->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 16.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->emailtext->Location = System::Drawing::Point(278, 84);
			this->emailtext->Name = L"emailtext";
			this->emailtext->Size = System::Drawing::Size(335, 38);
			this->emailtext->TabIndex = 1;
			// 
			// passwordtext
			// 
			this->passwordtext->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 16.2F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->passwordtext->Location = System::Drawing::Point(278, 196);
			this->passwordtext->Name = L"passwordtext";
			this->passwordtext->Size = System::Drawing::Size(335, 38);
			this->passwordtext->TabIndex = 2;
			// 
			// password
			// 
			this->password->AutoSize = true;
			this->password->BackColor = System::Drawing::SystemColors::Control;
			this->password->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 16.2F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->password->Location = System::Drawing::Point(12, 202);
			this->password->Name = L"password";
			this->password->Size = System::Drawing::Size(203, 32);
			this->password->TabIndex = 3;
			this->password->Text = L"PASSWORD: ";
			// 
			// okbutton
			// 
			this->okbutton->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 13.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->okbutton->Location = System::Drawing::Point(192, 262);
			this->okbutton->Name = L"okbutton";
			this->okbutton->Size = System::Drawing::Size(111, 38);
			this->okbutton->TabIndex = 4;
			this->okbutton->Text = L"OK";
			this->okbutton->UseVisualStyleBackColor = true;
			this->okbutton->Click += gcnew System::EventHandler(this, &MyForm::okbutton_Click);
			// 
			// cancelbutton
			// 
			this->cancelbutton->BackColor = System::Drawing::SystemColors::ControlLightLight;
			this->cancelbutton->Cursor = System::Windows::Forms::Cursors::Cross;
			this->cancelbutton->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 13.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->cancelbutton->Location = System::Drawing::Point(344, 262);
			this->cancelbutton->Name = L"cancelbutton";
			this->cancelbutton->Size = System::Drawing::Size(116, 38);
			this->cancelbutton->TabIndex = 5;
			this->cancelbutton->Text = L"Cancel";
			this->cancelbutton->UseVisualStyleBackColor = false;
			this->cancelbutton->Click += gcnew System::EventHandler(this, &MyForm::cancelbutton_Click);
			// 
			// login
			// 
			this->login->AutoSize = true;
			this->login->BackColor = System::Drawing::SystemColors::ControlLightLight;
			this->login->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 18, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->login->Location = System::Drawing::Point(272, 9);
			this->login->Name = L"login";
			this->login->Size = System::Drawing::Size(90, 36);
			this->login->TabIndex = 6;
			this->login->Text = L"Login";
			this->login->Click += gcnew System::EventHandler(this, &MyForm::label1_Click_1);
			// 
			// MyForm
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::SystemColors::HotTrack;
			this->ClientSize = System::Drawing::Size(648, 337);
			this->Controls->Add(this->login);
			this->Controls->Add(this->cancelbutton);
			this->Controls->Add(this->okbutton);
			this->Controls->Add(this->password);
			this->Controls->Add(this->passwordtext);
			this->Controls->Add(this->emailtext);
			this->Controls->Add(this->email);
			this->Name = L"MyForm";
			this->Text = L"MyForm";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void label1_Click(System::Object^ sender, System::EventArgs^ e) {
	}
	private: System::Void label1_Click_1(System::Object^ sender, System::EventArgs^ e) {
	}
private: System::Void cancelbutton_Click(System::Object^ sender, System::EventArgs^ e) {
	this->Close();
}
public: User^ user=nullptr;

private: System::Void okbutton_Click(System::Object^ sender, System::EventArgs^ e) {
	String^ email = this->emailtext->Text;
	String^ password = this->passwordtext->Text;
	if (email->Length == 0 || password->Length == 0) {
		MessageBox::Show("Please enter email and password",
			"Email or Password Empty", MessageBoxButtons::OK);;
		return;
	}
	try{
		String^ connString = "Data Source=LAPTOP-FGOVNBET;Integrated Security=True;Encrypt=False;";
		SqlConnection sqlConn(connString);
		sqlConn.Open();
		String^ sqlQuery = "SELECT *From users Where email=@email AND password=@pwd";
		SqlCommand command(sqlQuery, % sqlConn);
		command.Parameters->AddWithValue("@email", email);
		command.Parameters->AddWithValue("@pwd", password);
		SqlDataReader^ reader = command.ExecuteReader();
		if (reader->Read()) {
			user = gcnew User;
			user->id = reader->GetInt32(0);
			user->name = reader->GetString(1);
			user->email = reader->GetString(2);
			user->phone = reader->GetString(3);
			user->address = reader->GetString(4);
			user->password= reader->GetString(5);

			this->Close();
		}
		else {
			MessageBox::Show("Email or password is incorrect",
				"Email or passwprd Error", MessageBoxButtons::OK);
		}
	}
	catch (Exception^ e){
			MessageBox::Show("Failed to connect to the database. Error: " + e->Message,
				"Database Connection Error", MessageBoxButtons::OK);
	}
}
};
}
